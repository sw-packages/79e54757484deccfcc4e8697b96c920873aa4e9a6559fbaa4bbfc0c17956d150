// Note the second line of this file must ALWAYS be the git SHA, third line ALWAYS the git SHA update time
#define LLFIO_PREVIOUS_COMMIT_REF    2adf5ca3d7e14be83a8d4bd4de05615c4249bbc7
#define LLFIO_PREVIOUS_COMMIT_DATE   "2018-12-15 14:00:31 +00:00"
#define LLFIO_PREVIOUS_COMMIT_UNIQUE 2adf5ca3
